# Copyright (c) Microsoft Corporation.
# Licensed under the Apache License 2.0.

from knack.help_files import helps


helps['aro'] = """
    type: group
    short-summary: Manage Azure Red Hat OpenShift clusters.
"""

helps['aro create'] = """
    type: command
    short-summary: Create a cluster.
"""

helps['aro list'] = """
    type: command
    short-summary: List clusters.
"""

helps['aro delete'] = """
    type: command
    short-summary: Delete a cluster.
"""

helps['aro show'] = """
    type: command
    short-summary: Get the details of a cluster.
"""

helps['aro update'] = """
    type: command
    short-summary: Update a cluster.
"""

helps['aro list-credentials'] = """
    type: command
    short-summary: List credentials of a cluster.
"""

helps['aro wait'] = """
    type: command
    short-summary: Wait for a cluster to reach a desired state.
    long-summary: If an operation on a cluster was interrupted or was started with `--no-wait`, use this command to wait for it to complete.
"""
