Microsoft Azure CLI 'aro' Extension
==========================================

This package is for the 'aro' extension.
i.e. 'az aro'


.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.


